/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet;

/**
 *
 * @author PC MC
 */
public class Temp {
    
    int Temperature_Kelvin() {
        return 0;

/*
               System.out.println("Temperature in Degree Celsius:");		
		br = new BufferedReader(new InputStreamReader(System.in));
		// assign to float variable the degree celsius
		float celsius = Float.parseFloat(br.readLine());
		// Degrees Celsius to Kelvin Conversion
		float kelvin = celsius + 273.15F;

		System.out.println("Kelvin: "+ kelvin);

*/

}
    
}
